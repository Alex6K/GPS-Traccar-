import 'dart:io';

import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';

class OemHelpScreen extends StatelessWidget {
  const OemHelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ayuda de supervivencia'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _headerCard(context),
          const SizedBox(height: 16),
          _sectionTitle(context, 'Pasos recomendados (todos los fabricantes)'),
          _stepCard(
            context,
            number: '1',
            title: 'Desactivar optimización de batería',
            description:
                'La app debe poder ejecutarse sin restricciones de batería. Si está optimizada, el sistema la matará en segundo plano.',
            actionLabel: 'Abrir optimización de batería',
            onAction: () => AppSettings.openAppSettings(type: AppSettingsType.batteryOptimization),
          ),
          _stepCard(
            context,
            number: '2',
            title: 'Permitir actividad en segundo plano',
            description:
                'Algunos fabricantes tienen un interruptor específico de “Permitir actividad en segundo plano” o “Sin restricciones”.',
            actionLabel: 'Abrir ajustes de la app',
            onAction: () => AppSettings.openAppSettings(type: AppSettingsType.settings),
          ),
          _stepCard(
            context,
            number: '3',
            title: 'Bloquear en recientes / Autostart',
            description:
                'En la pantalla de apps recientes, bloquea la app (candado o icono de pin) para que no se cierre al limpiar.',
            actionLabel: null,
            onAction: null,
          ),
          const SizedBox(height: 8),
          _sectionTitle(context, 'Fabricantes problemáticos'),
          _manufacturerCard(
            context,
            brand: 'Xiaomi / Redmi / POCO (MIUI / HyperOS)',
            tips: [
              'Ajustes → Apps → Gestionar apps → GPS Traccar → Ahorro de batería → Sin restricciones',
              'Ajustes → Apps → Autostart → Activar GPS Traccar',
              'Bloquear la app en recientes (candado)',
              'Desactivar “Optimizar batería” o “Ahorro extremo”',
            ],
          ),
          _manufacturerCard(
            context,
            brand: 'Huawei / Honor',
            tips: [
              'Ajustes → Batería → Inicio de apps → GPS Traccar → Gestionar manualmente (activar las 3 opciones)',
              'Ajustes → Batería → Más ajustes de batería → desactivar “Ahorro de energía”',
              'Bloquear en recientes',
            ],
          ),
          _manufacturerCard(
            context,
            brand: 'Samsung',
            tips: [
              'Ajustes → Batería → Límites de uso en segundo plano → GPS Traccar → Sin restricciones',
              'Ajustes → Cuidado del dispositivo → Batería → Apps nunca en suspensión → Añadir GPS Traccar',
              'Desactivar “Poner en suspensión apps no usadas”',
            ],
          ),
          _manufacturerCard(
            context,
            brand: 'Oppo / Realme / OnePlus (ColorOS / OxygenOS)',
            tips: [
              'Ajustes → Batería → Uso de batería de apps → GPS Traccar → Permitir actividad en segundo plano',
              'Ajustes → Apps → Autostart → Activar',
              'Bloquear en recientes',
            ],
          ),
          _manufacturerCard(
            context,
            brand: 'Vivo / iQOO',
            tips: [
              'Ajustes → Batería → Gestión de alto consumo en segundo plano → Permitir',
              'Ajustes → Más ajustes → Apps → Autostart',
              'Bloquear en recientes',
            ],
          ),
          const SizedBox(height: 16),
          _infoCard(context),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _headerCard(BuildContext context) {
    return Card(
      color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.4),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.security_rounded, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Importante para flota',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Los fabricantes (especialmente Xiaomi, Huawei y Samsung) matan apps de GPS en segundo plano para ahorrar batería. '
              'Sigue estos pasos en cada dispositivo para que el tracking sea fiable.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            if (Platform.isAndroid) ...[
              const SizedBox(height: 12),
              Text(
                'Dispositivo detectado: Android',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(BuildContext context, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, top: 4),
      child: Text(
        text,
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w600,
              color: Theme.of(context).colorScheme.primary,
            ),
      ),
    );
  }

  Widget _stepCard(
    BuildContext context, {
    required String number,
    required String title,
    required String description,
    String? actionLabel,
    VoidCallback? onAction,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 14,
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  child: Text(
                    number,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onPrimary,
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    title,
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(description, style: Theme.of(context).textTheme.bodyMedium),
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: 10),
              Align(
                alignment: Alignment.centerRight,
                child: FilledButton.tonal(
                  onPressed: onAction,
                  child: Text(actionLabel),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _manufacturerCard(
    BuildContext context, {
    required String brand,
    required List<String> tips,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ExpansionTile(
        title: Text(brand, style: const TextStyle(fontWeight: FontWeight.w600)),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        children: tips
            .map(
              (tip) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('•  '),
                    Expanded(child: Text(tip, style: Theme.of(context).textTheme.bodyMedium)),
                  ],
                ),
              ),
            )
            .toList(),
      ),
    );
  }

  Widget _infoCard(BuildContext context) {
    return Card(
      color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Notas técnicas',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 6),
            Text(
              '• El SDK de Traccar ya incluye servicio en primer plano, reinicio tras arranque y buffer offline.\n'
              '• Esta pantalla ayuda a evitar que el fabricante mate el proceso.\n'
              '• Si el usuario detiene el tracking manualmente, no se reiniciará solo (flag de parada intencional).',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}
