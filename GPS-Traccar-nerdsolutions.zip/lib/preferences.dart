import 'dart:io';
import 'dart:math';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:shared_preferences_android/shared_preferences_android.dart';
import 'package:traccar_client_sdk/traccar_client_sdk.dart';

class Preferences {
  static Future<void>? _initFuture;
  static late SharedPreferencesWithCache instance;

  static const String id = 'id';
  static const String url = 'url';

  /// URL fija del servidor — no editable ni visible en la UI
  static const String fixedServerUrl = 'https://traccar.gamerzone.cu';

  static const String accuracy = 'accuracy';
  static const String distance = 'distance';
  static const String interval = 'interval';
  static const String angle = 'angle';
  static const String heartbeat = 'heartbeat';
  static const String buffer = 'buffer';
  static const String wakelock = 'wakelock';
  static const String stopDetection = 'stop_detection';
  static const String preferPlatformProviders = 'prefer_platform_providers';
  static const String password = 'password';
  static const String intentionalStop = 'intentional_stop'; // true = usuario detuvo conscientemente
  static const String termsAccepted = 'terms_accepted'; // onboarding / términos aceptados

  static Future<void> init() async {
    _initFuture ??= _createInstance();
    await _initFuture;
  }

  static Future<void> _createInstance() async {
    instance = await SharedPreferencesWithCache.create(
      sharedPreferencesOptions: Platform.isAndroid
          ? SharedPreferencesAsyncAndroidOptions(backend: SharedPreferencesAndroidBackendLibrary.SharedPreferences)
          : SharedPreferencesOptions(),
      cacheOptions: SharedPreferencesWithCacheOptions(
        allowList: {
          id, url, accuracy, distance, interval, angle, heartbeat, buffer, wakelock, stopDetection, preferPlatformProviders, password, intentionalStop, termsAccepted,
        },
      ),
    );
    if (Platform.isAndroid) {
      for (final key in {interval, distance, angle, heartbeat}) {
        if (instance.get(key) is String) {
          await instance.setInt(key, int.tryParse(instance.getString(key) ?? '') ?? 0);
        }
      }
    }
    // Siempre forzar la URL fija (no editable)
    await instance.setString(url, fixedServerUrl);

    if (instance.getString(id) == null) {
      await instance.setString(id, (Random().nextInt(90000000) + 10000000).toString());
      // Defaults orientados a flota: más frecuentes + GPS prioritario
      await instance.setString(accuracy, 'high');
      await instance.setInt(interval, 60); // 60 s (rango permitido 30–300)
      await instance.setInt(distance, 50);
      await instance.setBool(buffer, true);
      await instance.setBool(stopDetection, true);
      await instance.setBool(preferPlatformProviders, true); // fuerza LocationManager (más GPS puro)
    }
  }

  /// Intervalo de captura permitido: 30 – 300 segundos
  static const int minInterval = 30;
  static const int maxInterval = 300;

  static int clampInterval(int value) {
    if (value < minInterval) return minInterval;
    if (value > maxInterval) return maxInterval;
    return value;
  }

  static Config buildConfig() {
    return Config(
      serverUrl: fixedServerUrl,
      deviceId: instance.getString(id) ?? '',
      location: LocationConfig(
        accuracy: switch (instance.getString(accuracy)) {
          'highest' => Accuracy.highest,
          'high' => Accuracy.high,
          'low' => Accuracy.low,
          _ => Accuracy.medium,
        },
        distanceMeters: instance.getInt(distance) ?? 50,
        intervalSeconds: clampInterval(instance.getInt(interval) ?? 60),
        angleDegrees: instance.getInt(angle) ?? 0,
        heartbeatIntervalSeconds: instance.getInt(heartbeat) ?? 0,
        stopDetection: instance.getBool(stopDetection) ?? true,
      ),
      wakeLock: instance.getBool(wakelock) ?? false,
      buffer: instance.getBool(buffer) ?? true,
      preferPlatformProviders: instance.getBool(preferPlatformProviders) ?? true,
    );
  }
}
