import 'dart:developer' as developer;

import 'package:flutter/services.dart';
import 'package:traccar_client/preferences.dart';

import 'geolocation_service.dart';

/// Ayuda a recuperar el tracking cuando el sistema lo ha matado
/// pero el usuario no lo detuvo conscientemente.
class WatchdogService {
  /// Comprueba si el tracking debería estar activo y lo reinicia si es necesario.
  /// Respeta el flag de parada intencional.
  static Future<bool> checkAndRecover() async {
    final intentionalStop = Preferences.instance.getBool(Preferences.intentionalStop) ?? false;
    if (intentionalStop) {
      developer.log('Watchdog: parada intencional activa, no se reinicia');
      return false;
    }

    try {
      final isTracking = await GeolocationService.tracker.isTracking();
      if (isTracking) {
        return false; // todo bien
      }

      developer.log('Watchdog: tracking debería estar activo pero no lo está → reiniciando');
      await GeolocationService.tracker.start();
      return true;
    } on PlatformException catch (e) {
      developer.log('Watchdog: no se pudo reiniciar ($e)');
      return false;
    } catch (e) {
      developer.log('Watchdog: error inesperado ($e)');
      return false;
    }
  }

  /// Marca que el usuario detuvo el tracking conscientemente.
  static Future<void> markIntentionalStop() async {
    await Preferences.instance.setBool(Preferences.intentionalStop, true);
  }

  /// Marca que el usuario quiere que el tracking esté activo.
  static Future<void> clearIntentionalStop() async {
    await Preferences.instance.setBool(Preferences.intentionalStop, false);
  }
}
