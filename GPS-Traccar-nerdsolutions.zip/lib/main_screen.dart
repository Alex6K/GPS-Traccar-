import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:traccar_client/main.dart';
import 'package:traccar_client/password_service.dart';
import 'package:traccar_client/preferences.dart';
import 'package:traccar_client_sdk/traccar_client_sdk.dart';

import 'geolocation_service.dart';
import 'l10n/app_localizations.dart';
import 'oem_help_screen.dart';
import 'settings_screen.dart';
import 'status_screen.dart';
import 'watchdog_service.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => MainScreenState();
}

class MainScreenState extends State<MainScreen> with WidgetsBindingObserver {
  bool trackingEnabled = false;
  bool _syncing = false;
  String? _lastSyncText;
  bool _lastSyncOk = false;
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refreshState();
    _refreshTimer = Timer.periodic(const Duration(seconds: 8), (_) {
      if (WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed) {
        _refreshState();
      }
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _onResumed();
    }
  }

  Future<void> _onResumed() async {
    // Intentar recuperar el tracking si el sistema lo mató
    final recovered = await WatchdogService.checkAndRecover();
    if (recovered && mounted) {
      messengerKey.currentState?.showSnackBar(
        const SnackBar(
          content: Text('Seguimiento recuperado automáticamente'),
          duration: Duration(seconds: 3),
        ),
      );
    }
    await _refreshState();
  }

  Future<void> _refreshState() async {
    final tracking = await GeolocationService.tracker.isTracking();
    await _updateLastSyncFromLogs();
    if (!mounted) return;
    setState(() {
      trackingEnabled = tracking;
    });
  }

  Future<void> _updateLastSyncFromLogs() async {
    try {
      final logs = await GeolocationService.tracker.getLogs();
      // Look for recent successful upload messages (SDK logs vary by version)
      for (final entry in logs.reversed) {
        final msg = entry.message.toLowerCase();
        if (msg.contains('upload') || msg.contains('sent') || msg.contains('position') || msg.contains('http')) {
          final time = DateTime.fromMillisecondsSinceEpoch(entry.time);
          final diff = DateTime.now().difference(time);
          String relative;
          if (diff.inSeconds < 60) {
            relative = 'hace ${diff.inSeconds} s';
          } else if (diff.inMinutes < 60) {
            relative = 'hace ${diff.inMinutes} min';
          } else {
            relative = 'hace ${diff.inHours} h';
          }
          final isError = msg.contains('error') || msg.contains('fail') || msg.contains('failed');
          _lastSyncText = relative;
          _lastSyncOk = !isError;
          return;
        }
      }
    } catch (_) {
      // ignore log parsing errors
    }
  }

  void refresh() => setState(() {});

  Future<void> _toggleTracking(bool value) async {
    if (!await PasswordService.authenticate(context) || !mounted) return;

    if (value) {
      await WatchdogService.clearIntentionalStop();
      var started = false;
      try {
        await GeolocationService.tracker.start();
        started = true;
      } on PlatformException {
        // permission denied or startup error
      }
      if (!mounted) return;
      if (!started) {
        messengerKey.currentState?.showSnackBar(
          const SnackBar(
            content: Text('No se pudo iniciar el seguimiento. Revisa los permisos de ubicación.'),
            duration: Duration(seconds: 4),
          ),
        );
      }
      setState(() => trackingEnabled = started);
    } else {
      await WatchdogService.markIntentionalStop();
      await GeolocationService.tracker.stop();
      if (mounted) setState(() => trackingEnabled = false);
    }
  }

  Future<void> _syncNow() async {
    if (_syncing) return;
    setState(() => _syncing = true);
    try {
      await GeolocationService.tracker.requestPosition();
      await _updateLastSyncFromLogs();
      if (mounted) {
        messengerKey.currentState?.showSnackBar(
          const SnackBar(content: Text('Posición enviada'), duration: Duration(seconds: 2)),
        );
      }
    } on PlatformException {
      if (mounted) {
        messengerKey.currentState?.showSnackBar(
          const SnackBar(content: Text('Error al enviar posición'), duration: Duration(seconds: 3)),
        );
      }
    } finally {
      if (mounted) setState(() => _syncing = false);
    }
  }

  String _accuracyLabel(String? value) {
    final l10n = AppLocalizations.of(context)!;
    return switch (value) {
      'highest' => l10n.highestAccuracyLabel,
      'high' => l10n.highAccuracyLabel,
      'low' => l10n.lowAccuracyLabel,
      _ => l10n.mediumAccuracyLabel,
    };
  }

  // ───────────────────── UI BUILDERS ─────────────────────

  Widget _buildStatusHeader() {
    final deviceId = Preferences.instance.getString(Preferences.id) ?? '—';
    final isTracking = trackingEnabled;

    return Card(
      elevation: 0,
      color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isTracking ? Colors.green : Colors.redAccent,
                    boxShadow: isTracking
                        ? [BoxShadow(color: Colors.green.withValues(alpha: 0.5), blurRadius: 8)]
                        : null,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    isTracking ? 'Capturando' : 'Detenido',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: isTracking ? Colors.green.shade700 : null,
                        ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'ID del dispositivo',
                        style: Theme.of(context).textTheme.labelMedium?.copyWith(
                              color: Theme.of(context).colorScheme.onSurfaceVariant,
                            ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        deviceId,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w600,
                              fontFamily: 'monospace',
                            ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Envía este ID al administrador para activar el dispositivo',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context).colorScheme.onSurfaceVariant,
                            ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton.tonalIcon(
                  onPressed: deviceId == '—'
                      ? null
                      : () async {
                          await Clipboard.setData(ClipboardData(text: deviceId));
                          if (!mounted) return;
                          messengerKey.currentState?.showSnackBar(
                            const SnackBar(
                              content: Text('ID copiado al portapapeles'),
                              duration: Duration(seconds: 2),
                            ),
                          );
                        },
                  icon: const Icon(Icons.copy_rounded, size: 18),
                  label: const Text('Copiar ID'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPendingCard() {
    final bufferOn = Preferences.instance.getBool(Preferences.buffer) ?? true;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Pendientes',
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    bufferOn ? 'Buffer activo' : 'Sin buffer',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: bufferOn ? Colors.green.shade700 : null,
                        ),
                  ),
                  Text(
                    bufferOn ? 'Los puntos se guardan sin conexión' : 'Solo envío en tiempo real',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
            Icon(
              bufferOn ? Icons.cloud_queue_rounded : Icons.cloud_off_rounded,
              size: 36,
              color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.7),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLastSyncCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Último sync',
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Icon(
                        _lastSyncOk ? Icons.check_circle_rounded : Icons.info_outline_rounded,
                        size: 20,
                        color: _lastSyncOk ? Colors.green : Theme.of(context).colorScheme.outline,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        _lastSyncText != null
                            ? (_lastSyncOk ? 'OK · $_lastSyncText' : _lastSyncText!)
                            : 'Sin datos aún',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Icon(
              Icons.sync_rounded,
              size: 32,
              color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.6),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConfigCard() {
    final interval = Preferences.instance.getInt(Preferences.interval) ?? 60;
    final accuracy = Preferences.instance.getString(Preferences.accuracy) ?? 'high';
    final preferPlatform = Preferences.instance.getBool(Preferences.preferPlatformProviders) ?? true;
    final gpsPuro = preferPlatform || accuracy == 'highest' || accuracy == 'high';

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Configuración actual',
              style: Theme.of(context).textTheme.labelLarge?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _chip('Intervalo ${interval}s'),
                _chip('Precisión ${_accuracyLabel(accuracy)}'),
                _chip(gpsPuro ? 'GPS prioritario' : 'Fused / Sistema'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _chip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: Theme.of(context).textTheme.bodySmall?.copyWith(
              fontWeight: FontWeight.w500,
            ),
      ),
    );
  }

  Widget _buildActionButtons() {
    return Row(
      children: [
        Expanded(
          child: FilledButton.icon(
            onPressed: () => _toggleTracking(!trackingEnabled),
            icon: Icon(trackingEnabled ? Icons.stop_rounded : Icons.play_arrow_rounded),
            label: Text(trackingEnabled ? 'Detener tracking' : 'Iniciar tracking'),
            style: FilledButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 14),
              backgroundColor: trackingEnabled
                  ? Theme.of(context).colorScheme.error
                  : Theme.of(context).colorScheme.primary,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: _syncing ? null : _syncNow,
            icon: _syncing
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.sync_rounded),
            label: const Text('Sincronizar'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSecondaryActions() {
    return Wrap(
      alignment: WrapAlignment.center,
      spacing: 4,
      runSpacing: 0,
      children: [
        TextButton.icon(
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const StatusScreen()));
          },
          icon: const Icon(Icons.list_alt_rounded, size: 18),
          label: const Text('Logs'),
        ),
        TextButton.icon(
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const OemHelpScreen()));
          },
          icon: const Icon(Icons.security_rounded, size: 18),
          label: const Text('Ayuda OEM'),
        ),
        TextButton.icon(
          onPressed: () async {
            try {
              await GeolocationService.tracker.requestPosition(alarm: 'sos');
              if (mounted) {
                messengerKey.currentState?.showSnackBar(
                  const SnackBar(content: Text('SOS enviado'), duration: Duration(seconds: 2)),
                );
              }
            } on PlatformException {
              // permission denied
            }
          },
          icon: Icon(Icons.sos_rounded, size: 18, color: Theme.of(context).colorScheme.error),
          label: Text(
            'SOS',
            style: TextStyle(color: Theme.of(context).colorScheme.error),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('GPS Traccar'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_rounded),
            tooltip: AppLocalizations.of(context)!.settingsTitle,
            onPressed: () async {
              if (await PasswordService.authenticate(context) && mounted) {
                await Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()));
                setState(() {});
              }
            },
          ),
          IconButton(
            icon: const Icon(Icons.list_alt_rounded),
            tooltip: AppLocalizations.of(context)!.statusTitle,
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const StatusScreen()));
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildStatusHeader(),
            const SizedBox(height: 12),
            _buildPendingCard(),
            const SizedBox(height: 10),
            _buildLastSyncCard(),
            const SizedBox(height: 10),
            _buildConfigCard(),
            const SizedBox(height: 20),
            _buildActionButtons(),
            const SizedBox(height: 12),
            _buildSecondaryActions(),
            if (Platform.isAndroid) ...[
              const SizedBox(height: 16),
              Text(
                AppLocalizations.of(context)!.disclosureMessage,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                textAlign: TextAlign.center,
              ),
            ],
          ],
        ),
      ),
    );
  }
}
