/// Push notifications deshabilitadas (Firebase eliminado).
/// Se mantiene la clase vacía por si en el futuro se reintroduce otro proveedor.
class PushService {
  static Future<void> init() async {
    // Sin Firebase: no hay push
  }
}
