import 'package:flutter/material.dart';

import 'oem_help_screen.dart';
import 'preferences.dart';

class OnboardingScreen extends StatefulWidget {
  final VoidCallback onAccepted;

  const OnboardingScreen({super.key, required this.onAccepted});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  bool _acceptedTerms = false;

  static const int _totalPages = 3;

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _finish() async {
    if (!_acceptedTerms) return;
    await Preferences.instance.setBool(Preferences.termsAccepted, true);
    widget.onAccepted();
  }

  void _next() {
    if (_currentPage < _totalPages - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    } else {
      _finish();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLast = _currentPage == _totalPages - 1;

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: PageView(
                controller: _pageController,
                onPageChanged: (i) => setState(() => _currentPage = i),
                children: [
                  _pageWelcome(context),
                  _pageHowItWorks(context),
                  _pageTerms(context),
                ],
              ),
            ),
            _buildBottomBar(context, isLast),
          ],
        ),
      ),
    );
  }

  Widget _pageWelcome(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.location_on_rounded,
            size: 80,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(height: 24),
          Text(
            'GPS Traccar',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          Text(
            'Cliente de rastreo GPS para flota.\nEnvía la ubicación de este dispositivo a tu servidor Traccar.',
            style: Theme.of(context).textTheme.bodyLarge,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 32),
          _featureRow(context, Icons.gps_fixed, 'Captura en segundo plano'),
          _featureRow(context, Icons.cloud_queue, 'Buffer offline (sin perder puntos)'),
          _featureRow(context, Icons.security, 'Ayuda anti-kill para Xiaomi, Huawei…'),
          _featureRow(context, Icons.lock_outline, 'Protección opcional con contraseña'),
        ],
      ),
    );
  }

  Widget _pageHowItWorks(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 16),
          Text(
            'Cómo funciona',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          _step(context, '1', 'Configura el servidor', 'URL de tu Traccar + identificador del dispositivo (o escanea un QR).'),
          _step(context, '2', 'Activa el tracking', 'El servicio se ejecuta en segundo plano y envía posiciones según el intervalo configurado.'),
          _step(context, '3', 'Configura la batería', 'En Xiaomi, Huawei y similares debes desactivar las optimizaciones. Usa la “Ayuda OEM”.'),
          _step(context, '4', 'Monitorea el estado', 'En la pantalla principal verás si está capturando, el buffer y el último envío.'),
          const Spacer(),
          Card(
            color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.4),
            child: ListTile(
              leading: const Icon(Icons.security_rounded),
              title: const Text('Ver ayuda OEM ahora'),
              subtitle: const Text('Recomendado en Xiaomi / Redmi / Huawei'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const OemHelpScreen()));
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _pageTerms(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 16),
          Text(
            'Términos de uso',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: SingleChildScrollView(
              child: Text(
                'Al usar esta aplicación aceptas lo siguiente:\n\n'
                '• Esta app recopila datos de ubicación y actividad del dispositivo en segundo plano y los envía únicamente al servidor que configures (Traccar u otro compatible).\n\n'
                '• No se envían datos a terceros ni a servidores del desarrollador. Tú controlas el destino de la información.\n\n'
                '• El tracking en segundo plano requiere permisos de ubicación (incluyendo “siempre”) y, en muchos fabricantes, desactivar optimizaciones de batería.\n\n'
                '• Eres responsable de informar a los conductores o usuarios del dispositivo de que su ubicación está siendo rastreada, según la legislación aplicable.\n\n'
                '• El uso de esta app es bajo tu propia responsabilidad. El desarrollador no se hace cargo del mal uso ni de fallos causados por restricciones del sistema operativo o del fabricante.\n\n'
                'Si no estás de acuerdo, no uses la aplicación.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
          ),
          const SizedBox(height: 12),
          CheckboxListTile(
            value: _acceptedTerms,
            onChanged: (v) => setState(() => _acceptedTerms = v ?? false),
            title: const Text('He leído y acepto los términos'),
            controlAffinity: ListTileControlAffinity.leading,
            contentPadding: EdgeInsets.zero,
          ),
        ],
      ),
    );
  }

  Widget _featureRow(BuildContext context, IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, color: Theme.of(context).colorScheme.primary, size: 22),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: Theme.of(context).textTheme.bodyMedium)),
        ],
      ),
    );
  }

  Widget _step(BuildContext context, String num, String title, String body) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 14,
            backgroundColor: Theme.of(context).colorScheme.primary,
            child: Text(num, style: TextStyle(color: Theme.of(context).colorScheme.onPrimary, fontSize: 13, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(body, style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomBar(BuildContext context, bool isLast) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(_totalPages, (i) {
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: _currentPage == i ? 20 : 8,
                height: 8,
                decoration: BoxDecoration(
                  color: _currentPage == i
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.outlineVariant,
                  borderRadius: BorderRadius.circular(4),
                ),
              );
            }),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: isLast && !_acceptedTerms ? null : _next,
              style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
              child: Text(isLast ? 'Empezar' : 'Siguiente'),
            ),
          ),
          if (!isLast)
            TextButton(
              onPressed: () {
                _pageController.animateToPage(
                  _totalPages - 1,
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              },
              child: const Text('Saltar'),
            ),
        ],
      ),
    );
  }
}
