package com.nerdsolutions.gpstracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
